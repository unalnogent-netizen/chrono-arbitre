package fr.chronometre.arbitre

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.WindowManager
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("chrono_arbitre_v2", MODE_PRIVATE) }

    private lateinit var timeText: TextView
    private lateinit var statusText: TextView
    private lateinit var statsText: TextView
    private lateinit var historyBox: LinearLayout
    private lateinit var startPauseButton: Button

    private var running = false
    private var accumulatedMs = 0L
    private var startedAtMs = 0L
    private val events = mutableListOf<MatchEvent>()

    data class MatchEvent(
        val minute: Long,
        val type: String,
        val team: String,
        val player: String = "",
        val reason: String = "",
        val extra: String = ""
    )

    private val ticker = object : Runnable {
        override fun run() {
            refreshDisplay()
            if (running) handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        accumulatedMs = prefs.getLong("accumulated", 0L)
        running = prefs.getBoolean("running", false)
        startedAtMs = prefs.getLong("startedAt", 0L)
        if (running && startedAtMs <= 0L) running = false
        loadEvents()
        buildInterface()
        refreshAll()
        if (running) handler.post(ticker)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildInterface() {
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(12), dp(12), dp(12), dp(18))
            setBackgroundColor(Color.BLACK)
        }

        val heading = TextView(this).apply {
            text = "CHRONO ARBITRE"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        timeText = TextView(this).apply {
            text = "0"
            textSize = 58f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        val unit = TextView(this).apply {
            text = "MINUTES ÉCOULÉES"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        statusText = TextView(this).apply {
            textSize = 10f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }

        startPauseButton = makeButton(if (running) "PAUSE" else "DÉMARRER") {
            if (running) pauseChrono() else startChrono()
        }
        val resetButton = makeButton("REMISE À ZÉRO") { confirmReset() }
        root.addView(heading, matchParams())
        root.addView(timeText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72)))
        root.addView(unit, matchParams())
        root.addView(statusText, matchParams())
        root.addView(startPauseButton, matchParams())
        root.addView(resetButton, matchParams())

        addSection(root, "CARTONS")
        addAction(root, "🟨 Jaune", "Carton jaune", true)
        addAction(root, "🟥 Rouge", "Carton rouge", true)

        addSection(root, "STATISTIQUES")
        addAction(root, "⚽ But", "But", false)
        addAction(root, "🔄 Remplacement", "Remplacement", false)
        addAction(root, "⚑ Faute", "Faute", false)
        addAction(root, "＋ Blessure", "Blessure", false)

        addSection(root, "BILAN DU MATCH")
        statsText = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(6), dp(4), dp(8))
        }
        root.addView(statsText, matchParams())

        addSection(root, "HISTORIQUE")
        historyBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(8))
        }
        root.addView(historyBox, matchParams())

        val exportButton = makeButton("PARTAGER LE BILAN") { shareReport() }
        root.addView(exportButton, matchParams())

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun matchParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(5) }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun addSection(root: LinearLayout, title: String) {
        val label = TextView(this).apply {
            text = title
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.CYAN)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
        }
        root.addView(label, matchParams())
    }

    private fun addAction(root: LinearLayout, label: String, type: String, detailed: Boolean) {
        root.addView(makeButton(label) {
            if (detailed) askTeamAndDetails(type) else askTeam(type)
        }, matchParams())
    }

    private fun currentElapsed(): Long =
        if (running && startedAtMs > 0L)
            accumulatedMs + (System.currentTimeMillis() - startedAtMs).coerceAtLeast(0L)
        else accumulatedMs

    private fun currentMinute(): Long = currentElapsed() / 60_000L

    private fun refreshDisplay() {
        timeText.text = String.format(Locale.FRANCE, "%d", currentMinute())
        statusText.text = if (running) "EN COURS" else "EN PAUSE / ARRÊTÉ"
        startPauseButton.text = if (running) "PAUSE" else "DÉMARRER"
    }

    private fun refreshAll() {
        refreshDisplay()
        refreshStats()
        refreshHistory()
    }

    private fun startChrono() {
        if (running) return
        running = true
        startedAtMs = System.currentTimeMillis()
        saveTimer()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        refreshDisplay()
    }

    private fun pauseChrono() {
        if (!running) return
        accumulatedMs = currentElapsed()
        running = false
        startedAtMs = 0L
        saveTimer()
        handler.removeCallbacks(ticker)
        refreshDisplay()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Nouveau match ?")
            .setMessage("Remettre le chronomètre à zéro et effacer tous les événements enregistrés ?")
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Tout effacer") { _, _ ->
                running = false
                accumulatedMs = 0L
                startedAtMs = 0L
                events.clear()
                saveTimer()
                saveEvents()
                handler.removeCallbacks(ticker)
                refreshAll()
            }.show()
    }

    private fun saveTimer() {
        prefs.edit()
            .putLong("accumulated", accumulatedMs)
            .putBoolean("running", running)
            .putLong("startedAt", startedAtMs)
            .apply()
    }

    private fun askTeam(type: String) {
        chooseTeam { team ->
            val extra = if (type == "Remplacement") {
                askSubstitutionDetails(team)
                return@chooseTeam
            } else ""
            addEvent(MatchEvent(currentMinute(), type, team, extra = extra))
        }
    }

    private fun askTeamAndDetails(type: String) {
        chooseTeam { team ->
            val layout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(8), dp(20), 0)
            }
            val playerInput = EditText(this).apply {
                hint = "Numéro du joueur"
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                textSize = 16f
            }
            val reasonInput = EditText(this).apply {
                hint = "Motif du carton"
                textSize = 14f
                minLines = 2
            }
            layout.addView(playerInput)
            layout.addView(reasonInput)
            AlertDialog.Builder(this)
                .setTitle("$type – équipe $team")
                .setView(layout)
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Enregistrer") { _, _ ->
                    val player = playerInput.text.toString().trim()
                    val reason = reasonInput.text.toString().trim()
                    if (player.isBlank()) {
                        Toast.makeText(this, "Indique le numéro du joueur", Toast.LENGTH_LONG).show()
                    } else {
                        addEvent(MatchEvent(currentMinute(), type, team, player, reason))
                    }
                }.show()
        }
    }

    private fun chooseTeam(onChosen: (String) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("Choisir l'équipe")
            .setItems(arrayOf("Équipe BLEUE", "Équipe ROUGE")) { _, which ->
                onChosen(if (which == 0) "BLEUE" else "ROUGE")
            }.setNegativeButton("Annuler", null)
            .show()
    }

    private fun askSubstitutionDetails(team: String) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val outInput = EditText(this).apply {
            hint = "Numéro du joueur sortant (facultatif)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        val inInput = EditText(this).apply {
            hint = "Numéro du joueur entrant (facultatif)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(outInput)
        layout.addView(inInput)
        AlertDialog.Builder(this)
            .setTitle("Remplacement – $team")
            .setView(layout)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer") { _, _ ->
                val detail = "sortant ${outInput.text}; entrant ${inInput.text}"
                addEvent(MatchEvent(currentMinute(), "Remplacement", team, extra = detail))
            }.show()
    }

    private fun addEvent(event: MatchEvent) {
        events.add(event)
        saveEvents()
        refreshAll()
        Toast.makeText(this, "${event.type} enregistré – ${event.minute} min", Toast.LENGTH_SHORT).show()
    }

    private fun refreshStats() {
        fun count(type: String, team: String) = events.count { it.type == type && it.team == team }
        val lines = listOf(
            "ÉQUIPE BLEUE",
            "Buts ${count("But","BLEUE")}  •  Jaunes ${count("Carton jaune","BLEUE")}  •  Rouges ${count("Carton rouge","BLEUE")}",
            "Remplacements ${count("Remplacement","BLEUE")}  •  Fautes ${count("Faute","BLEUE")}  •  Blessures ${count("Blessure","BLEUE")}",
            "",
            "ÉQUIPE ROUGE",
            "Buts ${count("But","ROUGE")}  •  Jaunes ${count("Carton jaune","ROUGE")}  •  Rouges ${count("Carton rouge","ROUGE")}",
            "Remplacements ${count("Remplacement","ROUGE")}  •  Fautes ${count("Faute","ROUGE")}  •  Blessures ${count("Blessure","ROUGE")}"
        )
        statsText.text = lines.joinToString("\n")
    }

    private fun refreshHistory() {
        historyBox.removeAllViews()
        if (events.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Aucun événement enregistré."
                setTextColor(Color.GRAY)
                textSize = 11f
                gravity = Gravity.CENTER
            }
            historyBox.addView(empty)
            return
        }
        events.asReversed().take(30).forEach { event ->
            val detail = buildString {
                append("${event.minute}'  ${event.type} – ${event.team}")
                if (event.player.isNotBlank()) append("  •  N° ${event.player}")
                if (event.reason.isNotBlank()) append("\nMotif : ${event.reason}")
                if (event.extra.isNotBlank()) append("\n${event.extra}")
            }
            val row = TextView(this).apply {
                text = detail
                textSize = 11f
                setTextColor(Color.WHITE)
                setPadding(dp(5), dp(5), dp(5), dp(5))
            }
            historyBox.addView(row, matchParams())
        }
    }

    private fun saveEvents() {
        val array = JSONArray()
        events.forEach { e ->
            array.put(JSONObject().apply {
                put("minute", e.minute); put("type", e.type); put("team", e.team)
                put("player", e.player); put("reason", e.reason); put("extra", e.extra)
            })
        }
        prefs.edit().putString("events", array.toString()).apply()
    }

    private fun loadEvents() {
        val raw = prefs.getString("events", "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                events.add(MatchEvent(
                    o.optLong("minute"), o.optString("type"), o.optString("team"),
                    o.optString("player"), o.optString("reason"), o.optString("extra")
                ))
            }
        } catch (_: Exception) { events.clear() }
    }

    private fun shareReport() {
        val report = buildString {
            append("BILAN CHRONO ARBITRE\n")
            append("Durée : ${currentMinute()} minutes\n\n")
            append(statsText.text).append("\n\n")
            append("HISTORIQUE\n")
            events.forEach { e ->
                append("${e.minute}' – ${e.type} – ${e.team}")
                if (e.player.isNotBlank()) append(" – N° ${e.player}")
                if (e.reason.isNotBlank()) append(" – ${e.reason}")
                if (e.extra.isNotBlank()) append(" – ${e.extra}")
                append("\n")
            }
        }
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_SUBJECT, "Bilan du match – Chrono Arbitre")
            putExtra(android.content.Intent.EXTRA_TEXT, report)
        }
        startActivity(android.content.Intent.createChooser(intent, "Partager le bilan du match"))
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        saveTimer()
        super.onDestroy()
    }
}
