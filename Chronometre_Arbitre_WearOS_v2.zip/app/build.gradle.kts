plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "fr.chronometre.arbitre"
    compileSdk = 35
    defaultConfig {
        applicationId = "fr.chronometre.arbitre"
        minSdk = 30
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
