# Chrono Arbitre – Version 2.0 (Wear OS)

## Nouveautés
- Chronomètre affiché en minutes cumulées (60, 90, 105, 120… jamais en heures).
- Démarrer / pause / remise à zéro avec confirmation.
- Carton jaune et carton rouge : choix BLEUE ou ROUGE, numéro du joueur obligatoire, motif facultatif.
- Enregistrement des buts, remplacements, fautes et blessures par équipe.
- Pour un remplacement, saisie facultative des numéros entrant et sortant.
- Bilan statistique par équipe et historique avec minute de l'événement.
- Données sauvegardées localement sur la montre.
- Partage du bilan en texte vers une application compatible (mail, notes, etc.).

## Compilation
1. Ouvrir le dossier dans Android Studio.
2. Laisser Gradle se synchroniser (connexion Internet requise au premier lancement).
3. Sélectionner la montre Wear OS comme appareil de destination.
4. Cliquer sur Run pour installer sur la montre.

Le ZIP contient le code source Android Studio, pas un APK précompilé.
